module.exports.sendNotification = (message) => {
  console.log(`Notification: ${message}`);
};
